﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TvMazeApi.Model
{
	public class TvMazeApiContext : DbContext
	{
		public TvMazeApiContext(DbContextOptions<TvMazeApiContext> options)
			: base(options)
		{
		}

		public DbSet<Show> Shows { get; set; }
		public DbSet<Actor> Actors { get; set; }
	}
}
