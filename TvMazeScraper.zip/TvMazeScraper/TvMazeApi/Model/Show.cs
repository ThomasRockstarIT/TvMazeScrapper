﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TvMazeApi.Model
{
	public class Show
	{
		public long Id { get; set; }
		public string Name { get; set; }
		public List<Actor> Cast { get; set; }

		public Show SortedView()
		{
			return new Show
			{
				Id = Id,
				Name = Name,
				Cast = Cast.Select(c => new Actor
				{
					Id = c.Id,
					Name = c.Name,
					Birthday = c.Birthday
				}).OrderByDescending(o => o.Birthday).ToList()
			};
		}
	}

	
}
