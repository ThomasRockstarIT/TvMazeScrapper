﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TvMazeApi.Model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TvMazeApi.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class TvMazeController : Controller
	{
		private readonly TvMazeApiContext _context;
		private static int PAGESIZE = 20;

		public TvMazeController(TvMazeApiContext context)
		{
			_context = context;

			//TODO remove this when actual database connection is setup
			if (_context.Shows.Count() == 0)
			{
				_context.Actors.Add(new Actor() { Id = 1, Name = "Actor1", Birthday = new DateTime(1980, 01, 20) });
				_context.Actors.Add(new Actor() { Id = 2, Name = "Actor2", Birthday = new DateTime(1970, 01, 21) });
				_context.Actors.Add(new Actor() { Id = 3, Name = "Actor3", Birthday = new DateTime(1990, 01, 22) });
				_context.Actors.Add(new Actor() { Id = 4, Name = "Actor4", Birthday = new DateTime(1982, 01, 23) });
				_context.Actors.Add(new Actor() { Id = 5, Name = "Actor5", Birthday = new DateTime(1988, 01, 23) });

				_context.SaveChanges();

				// Create a new show if collection is empty,
				// which means you can't delete all show.
				_context.Shows.Add(new Show { Id = 1, Name = "testShow1", Cast = _context.Actors.ToList() });
				_context.Shows.Add(new Show { Id = 1, Name = "testShow2", Cast = _context.Actors.ToList() });
				_context.SaveChanges();
			}

			
		}

		/// <summary>
		/// Return fitst page of results
		/// </summary>
		/// <returns></returns>
		// GET: api/tvmaze
		[HttpGet]
		public async Task<ActionResult<List<Show>>> GetShows()
		{
			var tempresults = await _context.Shows.ToListAsync();
			var result = new List<Show>();

			foreach(var re in tempresults)
			{
				result.Add(re.SortedView());
			}
			
			return Ok(result);
		}


		/// <summary>
		/// Return n page or results
		/// </summary>
		/// <param name="n"></param>
		/// <returns></returns>
		// GET: api/tvmaze/1
		[HttpGet("{n}")]
		public async Task<ActionResult<List<Show>>> GetShow(short n)
		{
			var tempresults = await _context.Shows.ToListAsync();
			var result = new List<Show>();

			for(int i = n*PAGESIZE; i < tempresults.Count && i < n*PAGESIZE + PAGESIZE; i++)
			{
				result.Add(tempresults[i].SortedView());

			}

			return Ok(result);
		}
	}
}
