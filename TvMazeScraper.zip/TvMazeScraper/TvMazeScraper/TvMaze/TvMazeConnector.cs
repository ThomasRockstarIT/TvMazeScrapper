﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace TvMazeScraper
{
	class TvMazeConnector
	{
		private static readonly HttpClient client = new HttpClient();

		public TvMazeConnector()
		{

		}

		/// <summary>
		/// Returns one show based on given ID
		/// </summary>
		/// <param name="showId"></param>
		/// <returns></returns>
		public Show GetShow(int showId)
		{
			return ProcessShow(showId).Result;
		}

		/// <summary>
		/// Returns a list of shows
		/// </summary>
		/// <param name="startId"></param>
		/// <param name="numberOfShows"></param>
		/// <returns></returns>
		public List<Show> GetNumberOfShows(int startId, int numberOfShows)
		{
			List<Show> shows = new List<Show>();
			int showId = startId + numberOfShows;

			//Get initial set
			List<Task<Show>> showsT = new List<Task<Show>>();
			for (int i = startId; i < startId + numberOfShows; i++)
			{
				showsT.Add(ProcessShow(i));
			}

			Task.WaitAll(showsT.ToArray());

			//Add all shows that are not empty to a list
			foreach(var showT in showsT)
			{
				if(showT.Result != null)
				{
					shows.Add(showT.Result);
				}
			}

			while(shows.Count < numberOfShows)
			{
				Show tempShow = GetShow(showId);
				if(tempShow != null)
				{
					shows.Add(tempShow);
				}
				showId++;
			}

			return shows;
		}

		/// <summary>
		/// Create task to collect show
		/// </summary>
		/// <param name="showId"></param>
		/// <returns></returns>
		private static async Task<Show> ProcessShow(int showId)
		{
			var serializer = new DataContractJsonSerializer(typeof(Show));

			client.DefaultRequestHeaders.Accept.Clear();
			Show show = null;
			try
			{
				var streamTask = client.GetStreamAsync("http://api.tvmaze.com/shows/" + showId.ToString() + "?embed=cast");
				show = serializer.ReadObject(await streamTask) as Show;
			}
			catch { }
			
			return show;

		}
	}
}
