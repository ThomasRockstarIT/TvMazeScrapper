﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace TvMazeScraper
{
	[DataContract(Name = "image")]
	public class Image
	{
		[DataMember(Name = "medium")]
		public string Medium { get; set; }

		[DataMember(Name = "original")]
		public string Original { get; set; }
	}
}
