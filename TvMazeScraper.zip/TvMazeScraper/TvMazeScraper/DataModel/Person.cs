﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace TvMazeScraper
{
	[DataContract(Name = "person")]
	public class Person
	{
		[DataMember(Name = "id")]
		public int PersonID { get; set; }

		[DataMember(Name = "url")]
		public string Url { get; set; }

		[DataMember(Name = "name")]
		public string Name { get; set; }

		[DataMember(Name = "country")]
		public Country Country { get; set; }

		[DataMember(Name = "birthday")]
		private string birthday { get; set; }

		public DateTime? Birthday { get {
				return (!string.IsNullOrEmpty(birthday) ?
					new DateTime(int.Parse(birthday.Split('-')[0]), int.Parse(birthday.Split('-')[1]), int.Parse(birthday.Split('-')[2]))
					: DateTime.MinValue);
			}
		} 

		[DataMember(Name = "deathday")]
		public string Deathday { get; set; }

		[DataMember(Name = "gender")]
		public string Gender { get; set; }

		[DataMember(Name = "image")]
		public Image Image { get; set; }

		[DataMember(Name = "_links")]
		public Links Links { get; set; }
	}

}
