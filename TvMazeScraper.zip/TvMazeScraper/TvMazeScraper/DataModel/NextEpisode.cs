﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace TvMazeScraper
{
	[DataContract(Name = "nextepisode")]
	public class NextEpisode
	{
		[DataMember(Name = "href")]
		public string Href { get; set; }
	}
}
