﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace TvMazeScraper
{
	public class Network
	{
		[DataMember(Name = "id")]
		public int ID { get; set; }

		[DataMember(Name = "name")]
		public string Name { get; set; }

		[DataMember(Name = "country")]
		public Country Country { get; set; }
	}
}
