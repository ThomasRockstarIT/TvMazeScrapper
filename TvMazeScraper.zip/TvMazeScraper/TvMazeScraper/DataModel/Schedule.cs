﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace TvMazeScraper
{
	public class Schedule
	{
		[DataMember(Name = "time")]
		public string Time { get; set; }

		[DataMember(Name = "days")]
		public string[] Days { get; set; }
	}
}
