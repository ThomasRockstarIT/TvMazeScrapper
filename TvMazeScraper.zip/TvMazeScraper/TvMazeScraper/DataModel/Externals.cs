﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace TvMazeScraper
{
	public class Externals
	{
		[DataMember(Name = "tvrange")]
		public int TVrage { get; set; }

		[DataMember(Name = "thetvdb")]
		public int Thetvdb { get; set; }

		[DataMember(Name = "imdb")]
		public string Imdb { get; set; }
	}
}
