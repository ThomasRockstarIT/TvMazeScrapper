﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace TvMazeScraper
{
	[DataContract(Name = "_embedded")]
	public class Embeded
	{
		[DataMember(Name = "cast")]
		public CastMember[] CastMembers { get; set;}
	}

	[DataContract(Name = "cast")]
	public class CastMember
	{
		[DataMember(Name = "self")]
		public bool Self { get; set; }

		[DataMember(Name = "voice")]
		public bool Voice { get; set; }
		
		[DataMember(Name = "character")]
		public virtual Character Character { get; set; }

		[DataMember(Name = "person")]
		public virtual Person Person { get; set; }
	}
}
