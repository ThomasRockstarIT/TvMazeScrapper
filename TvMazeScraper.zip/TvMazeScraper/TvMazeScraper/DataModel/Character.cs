﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace TvMazeScraper
{
	[DataContract(Name = "character")]
	public class Character
	{
		[DataMember(Name = "id")]
		public int CharacterID { get; set; }

		[DataMember(Name = "url")]
		public string Url { get; set; }

		[DataMember(Name = "name")]
		public string Name { get; set; }
		
		[DataMember(Name = "image")]
		public Image Image { get; set; } 

		[DataMember(Name = "_links")]
		public Links Links { get; set; } 
		

	}
}
