﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace TvMazeScraper
{
	[DataContract(Name = "country")]
	public class Country
	{
		[DataMember(Name = "name")]
		public string Name { get; set; }

		[DataMember(Name = "code")]
		public string Code { get; set; }

		[DataMember(Name = "timezone")]
		public string Timezone { get; set; }
	}
}
