﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace TvMazeScraper
{
	[DataContract(Name = "show")]
	public class Show
	{
		/*
		//public string name;
		[DataMember(Name = "name")]
		public string Name;
		//*/

		//*

		[DataMember(Name = "id")]
		public int ShowID { get; set; }

		[DataMember(Name = "url")]
		public string Url { get; set; }

		[DataMember(Name = "name")]
		public string Name { get; set; }

		[DataMember(Name = "type")]
		public string Type { get; set; }

		[DataMember(Name = "language")]
		public string Language { get; set; }

		[DataMember(Name = "genres")]
		public string[] Genres { get; set; }

		[DataMember(Name = "status")]
		public string Status { get; set; }

		[DataMember(Name = "runtime")]
		public string Runtime { get; set; }

		[DataMember(Name = "premiered")]
		public string Premiered { get; set; }

		[DataMember(Name = "officialSite")]
		public string OfficialSite { get; set; }

		[DataMember(Name = "schedule")]
		public Schedule Schedule { get; set; }

		[DataMember(Name = "rating")]
		public Rating Rating { get; set; }

		[DataMember(Name = "weight")]
		public int Weight { get; set; }

		[DataMember(Name = "network")]
		public Network Network { get; set; }

		[DataMember(Name = "webchannel")]
		public WebChannel WebChannel { get; set; }

		[DataMember(Name = "externals")]
		public Externals Externals { get; set; }

		[DataMember(Name = "image")]
		public Image Image { get; set; } 

		[DataMember(Name = "summary")]
		public string Summary { get; set; }

		[DataMember(Name = "updated")]
		public int Updated { get; set; }

		[DataMember(Name = "_links")]
		public Links Links { get; set; }

		
		
		[DataMember(Name = "_embedded")]
		private Embeded Embeded { get; set; }

		[IgnoreDataMember]
		public CastMember[] Cast { get{ return this.Embeded.CastMembers; } }
	}
}
