﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace TvMazeScraper
{
	public class Rating
	{
		[DataMember(Name = "average")]
		public float? Average { get; set; }
	}
}
