﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace TvMazeScraper
{
	[DataContract(Name = "_links")]
	public class Links
	{
		[DataMember(Name = "self")]
		public Self Self { get; set; }

		[DataMember(Name = "previousepisode")]
		public PreviousEpisode Previousepisode { get; set; }

		[DataMember(Name = "nextepisode")]
		public NextEpisode NextEpisode { get; set; }
	}
}
