﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace TvMazeScraper.DBModel
{
	class DataContext : DbContext
	{
		public virtual DbSet<Actor> Actor { get; set; }
		public virtual DbSet<Show> Shows { get; set; }

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			optionsBuilder.UseSqlServer(
				@"Server=.\SQLEXPRESS;Database=TvMaze;Trusted_Connection=True;User ID=TVMaze;password=TVMaze");
				//@"Server=.\SQLEXPRESS;Database=TvMazeDB;Trusted_Connection=True;Integrated Security=True");
				//@"Server=(localdb)\mssqllocaldb;Database=TvMazeDB;Trusted_Connection=True;Integrated Security=True");
		}
	}
}
