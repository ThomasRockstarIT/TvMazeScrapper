﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TvMazeScraper.DBModel
{
	class Show
	{
		public long Id { get; set; }
		public string Name { get; set; }
		//public List<Actor> Cast { get; set; }

		public ICollection<Actor> Actors { get; set; }
	}
}
