﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TvMazeScraper.DBModel
{
	class Actor
	{
		public long Id { get; set; }
		public string Name { get; set; }
		public DateTime? Birthday { get; set; }

		public virtual Show Show { get; set; }
	}
}
