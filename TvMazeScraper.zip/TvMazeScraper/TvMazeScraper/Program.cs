﻿using System;
using System.Linq;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.Serialization.Json;
using System.Collections.Generic;
using TvMazeScraper.DBModel;

namespace TvMazeScraper
{
	class Program
	{
		static void Main(string[] args)
		{
			var shows = new TvMazeConnector().GetNumberOfShows(1, 20);

			foreach(var show in shows)
			{
				if(show != null) { 
					Console.WriteLine(show.ShowID + ", " + show.Name);
				}
			}

			//TODO collect all data in the database


			//*
			using (var context = new DataContext())
			{
				foreach(var s in shows)
				{
					List<Actor> tempActors = new List<Actor>();
					foreach (var c in s.Cast) {
						tempActors.Add(new Actor() { Id = c.Person.PersonID, Name = c.Person.Name, Birthday = c.Person.Birthday });

					};

					var tempShow = new DBModel.Show()
					{
						Id = s.ShowID,
						Name = s.Name,
						Actors = tempActors
					};

					context.Shows.Add(tempShow);
				}

				context.SaveChanges();

				var actors = (from a in context.Actor
								orderby a.Birthday
								select a).ToList<Actor>();

				foreach (var act in actors)
				{
					string name = act.Name;
					Console.WriteLine("ID: {0}, Name: {1}", act.Id, name);
				}
			}
			//*/


			Console.WriteLine("Press any key to exit...");
			Console.ReadKey();
		}

	}
}
